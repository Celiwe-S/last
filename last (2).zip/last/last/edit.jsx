import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, ScrollView, TextInput } from 'react-native';
// Only the chef is able to edit the menu as soon as they log in
export default function App() {
  const [starters, setStarters] = useState([
    "Baked Camembert",
    "Mushroom Soup",
    "Baked Feta",
    "Crème Brûlée"
  ]);

  const [mainCourses, setMainCourses] = useState([
    "Beef Enchiladas (beef strips with bacon and spinach)",
    "Stuffed Peppers (caramelized onions, mushrooms, and beef mince)",
    "Bacon Burger (chips/vegetables, cheese, pineapple, BBQ sauce)",
    "Lasagna (with ribs/vegetables)"
  ]);

  const [desserts, setDesserts] = useState([
    "Malva Pudding (homemade jam with cream and custard)",
    "Waffles and Ice Cream (Bar One/Oreo/Kit Kat)",
    "Lemon Meringue Pie (with Ice Cream)",
    "Chocolate Mousse (with Ice cream/custard)"
  ]);

  const [newItem, setNewItem] = useState('');

  const addItem = (item, setMenu, menu) => {
    if (item.trim() !== '') {
      setMenu([...menu, item]);
      setNewItem('');
    }
  };

  const removeItem = (index, setMenu, menu) => {
    const updatedMenu = [...menu];
    updatedMenu.splice(index, 1);
    setMenu(updatedMenu);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu</Text>

      <ScrollView style={styles.menuContainer}>
        {/* Starters Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Starters</Text>
          <Text style={styles.courseDescription}>
            A selection of light and flavorful appetizers to begin your meal.
          </Text>
          <Text style={styles.coursePrice}>R35.00</Text>
          {starters.map((starter, index) => (
            <View key={index} style={styles.menuItem}>
              <Text>{starter}</Text>
              <Button title="Remove" onPress={() => removeItem(index, setStarters, starters)} color="#800080" />
            </View>
          ))}
          <TextInput
            style={styles.input}
            placeholder="Add new starter"
            value={newItem}
            onChangeText={setNewItem}
          />
          <Button
            title="Add Starter"
            onPress={() => addItem(newItem, setStarters, starters)}
            color="#800080" // Make the "Add Starter" button purple
          />
        </View>

        {/* Main Course */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Main Course</Text>
          <Text style={styles.courseDescription}>
            Our finest main dishes to satisfy your hunger and cravings.
          </Text>
          <Text style={styles.coursePrice}>R105.99</Text>
          {mainCourses.map((main, index) => (
            <View key={index} style={styles.menuItem}>
              <Text>{main}</Text>
              <Button title="Remove" onPress={() => removeItem(index, setMainCourses, mainCourses)} color="#800080" />
            </View>
          ))}
          <TextInput
            style={styles.input}
            placeholder="Add new main course"
            value={newItem}
            onChangeText={setNewItem}
          />
          <Button
            title="Add Main Course"
            onPress={() => addItem(newItem, setMainCourses, mainCourses)}
            color="#800080" // Make the "Add Main Course" button purple
          />
        </View>

        {/* Dessert Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Dessert</Text>
          <Text style={styles.courseDescription}>
            Sweet and delightful desserts to end your meal on a high note.
          </Text>
          <Text style={styles.coursePrice}>R34.99 - R55.00</Text>
          {desserts.map((dessert, index) => (
            <View key={index} style={styles.menuItem}>
              <Text>{dessert}</Text>
              <Button title="Remove" onPress={() => removeItem(index, setDesserts, desserts)} color="#800080" />
            </View>
          ))}
          <TextInput
            style={styles.input}
            placeholder="Add new dessert"
            value={newItem}
            onChangeText={setNewItem}
          />
          <Button
            title="Add Dessert"
            onPress={() => addItem(newItem, setDesserts, desserts)}
            color="#800080" // Make the "Add Dessert" button purple
          />
        </View>

        {/* Next Page Button */}
        <View style={styles.nextPageButtonContainer}>
          <Button title="Ready To Check Out?" onPress={() => alert('Navigating to the next page')} color="#800080" />
        </View>
      </ScrollView>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    paddingTop: 50,
    alignItems: 'center',
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
  },
  menuContainer: {
    width: '90%',
  },
  courseContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    alignItems: 'center',
  },
  courseTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#333',
  },
  courseDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginVertical: 10,
  },
  coursePrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2a9d8f',
    marginBottom: 15,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginVertical: 5,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    width: '80%',
    marginBottom: 10,
    padding: 5,
    borderRadius: 5,
  },
  nextPageButtonContainer: {
    marginTop: 20,
  },
});