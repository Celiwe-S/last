import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Alert, TouchableOpacity } from 'react-native';

export default function App() {
  // Handler for button press
  const handlePress = () => {
    Alert.alert(
      "Menu",
      "Starters: Baked Caember, Mushroom Soup, Baked Feta, Tomato Bruschetta R35 - R40\nMain Courses: Beef Enchiladas, Stuffed Peppers, Bacon Burger, Lasagna R100 - R105\nDesserts: Malva Pudding, Waffles and Ice Cream, Lemon Meringue Pie, Chocolate Mousse R30 - R35"
    );
  };

  return (
    <View style={styles.container}>
      {/* Bold "Welcome to Celestial Bites" */}
      <Text style={styles.welcomeText}>Welcome to Celestial Bites</Text>
      
      <Text>Click the Button to See Menu</Text>
    
  
      <TouchableOpacity style={styles.purpleButton} onPress={handlePress}>
        <Text style={styles.buttonText}>See Menu</Text>
      </TouchableOpacity>

    
      <TouchableOpacity style={styles.purpleButton} onPress={handlePress}>
        <Text style={styles.buttonText}>Click to Log In</Text>
      </TouchableOpacity>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffc0cb',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',  
    marginBottom: 20,  
  },
  purpleButton: {
    backgroundColor: '#6a0dad',  // Purple background color
    paddingVertical: 12,
    paddingHorizontal: 40,
    marginTop: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',  // White text color
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',  // Center the text inside the button
  },
});
