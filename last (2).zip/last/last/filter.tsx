import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, ScrollView, TextInput } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import CheckoutScreen from './checkout'; // Import the Checkout Screen

// User is able to see the menu as it is updated by the chef
type MenuItem = string;

const Stack = createStackNavigator();

const App = () => {
  // State variables with types
  const [starters, setStarters] = useState<MenuItem[]>([
    "Baked Camembert",
    "Mushroom Soup",
    "Baked Feta",
    "Crème Brûlée"
  ]);

  const [mainCourses, setMainCourses] = useState<MenuItem[]>([
    "Beef Enchiladas (beef strips with bacon and spinach)",
    "Stuffed Peppers (caramelized onions, mushrooms, and beef mince)",
    "Bacon Burger (chips/vegetables, cheese, pineapple, BBQ sauce)",
    "Lasagna (with ribs/vegetables)"
  ]);

  const [desserts, setDesserts] = useState<MenuItem[]>([
    "Malva Pudding (homemade jam with cream and custard)",
    "Waffles and Ice Cream (Bar One/Oreo/Kit Kat)",
    "Lemon Meringue Pie (with Ice Cream)",
    "Chocolate Mousse (with Ice cream/custard)"
  ]);

  const [newItem, setNewItem] = useState<string>('');
  const [filter, setFilter] = useState<'all' | 'starters' | 'mainCourses' | 'desserts'>('all'); // Filtering state

  // Function to add a new menu item
  const addItem = (item: string, setMenu: React.Dispatch<React.SetStateAction<MenuItem[]>>, menu: MenuItem[]) => {
    if (item.trim() !== '') {
      setMenu([...menu, item]);
      setNewItem('');
    }
  };

  // Function to remove a menu item
  const removeItem = (index: number, setMenu: React.Dispatch<React.SetStateAction<MenuItem[]>>, menu: MenuItem[]) => {
    const updatedMenu = [...menu];
    updatedMenu.splice(index, 1);
    setMenu(updatedMenu);
  };

  // Rendering the menu based on the filter state
  const renderMenu = () => {
    switch (filter) {
      case 'starters':
        return (
          <View style={styles.courseContainer}>
            <Text style={styles.courseTitle}>Starters</Text>
            {starters.map((starter, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{starter}</Text>
                <Button title="Remove" onPress={() => removeItem(index, setStarters, starters)} />
              </View>
            ))}
          </View>
        );

      case 'mainCourses':
        return (
          <View style={styles.courseContainer}>
            <Text style={styles.courseTitle}>Main Course</Text>
            {mainCourses.map((main, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{main}</Text>
                <Button title="Remove" onPress={() => removeItem(index, setMainCourses, mainCourses)} />
              </View>
            ))}
          </View>
        );

      case 'desserts':
        return (
          <View style={styles.courseContainer}>
            <Text style={styles.courseTitle}>Dessert</Text>
            {desserts.map((dessert, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{dessert}</Text>
                <Button title="Remove" onPress={() => removeItem(index, setDesserts, desserts)} />
              </View>
            ))}
          </View>
        );

      default:
        return (
          <ScrollView style={styles.menuContainer}>
            <Text style={styles.courseTitle}>Starters</Text>
            {starters.map((starter, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{starter}</Text>
              </View>
            ))}
            <Text style={styles.courseTitle}>Main Course</Text>
            {mainCourses.map((main, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{main}</Text>
              </View>
            ))}
            <Text style={styles.courseTitle}>Dessert</Text>
            {desserts.map((dessert, index) => (
              <View key={index} style={styles.menuItem}>
                <Text>{dessert}</Text>
              </View>
            ))}
          </ScrollView>
        );
    }
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Menu">
        <Stack.Screen name="Menu">
          {(props) => (
            <View style={styles.container}>
              <Text style={styles.title}>Menu</Text>

              {/* Filter Buttons */}
              <View style={styles.filterContainer}>
                <Button title="All" onPress={() => setFilter('all')} />
                <Button title="Starters" onPress={() => setFilter('starters')} />
                <Button title="Main Courses" onPress={() => setFilter('mainCourses')} />
                <Button title="Desserts" onPress={() => setFilter('desserts')} />
              </View>

              {/* Render filtered menu */}
              {renderMenu()}

              <Text> Ready to Check Out?</Text>

              {/* Navigate to checkout */}
              <View style={styles.nextPageButtonContainer}>
                <Button title="Go to Checkout" onPress={() => props.navigation.navigate('Checkout')} />
              </View>

              <StatusBar style="auto" />
            </View>
          )}
        </Stack.Screen>
        
        {/* Checkout Screen */}
        <Stack.Screen name="Checkout" component={CheckoutScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    paddingTop: 50,
    alignItems: 'center',
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
  },
  menuContainer: {
    width: '90%',
  },
  courseContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    alignItems: 'center',
  },
  courseTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#333',
  },
  courseDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginVertical: 10,
  },
  coursePrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2a9d8f',
    marginBottom: 15,
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginVertical: 5,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    width: '80%',
    marginBottom: 10,
    padding: 5,
    borderRadius: 5,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 20,
  },
  nextPageButtonContainer: {
    marginTop: 20,
  },
});

export default App;
