import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Create a Stack Navigator
const Stack = createStackNavigator();

// Menu Screen
function MenuScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Menu</Text>
      <Text>Welcome to the menu! Here are some options for you.</Text>
      <StatusBar style="auto" />
    </View>
  );
}

// Login Screen
function LoginScreen({ navigation }) {
  const [chefPassword, setChefPassword] = useState('');
  const [customerPassword, setCustomerPassword] = useState('');

  // Simple login logic
  const handleChefLogin = () => {
    if (chefPassword === 'Chris101') {
      alert('Welcome Back Chef Chris');
      navigation.navigate('Menu'); // Navigate to Edit Menu Screen for Chef
    } else {
      alert('Incorrect Chef password.');
    }
  };

  const handleCustomerLogin = () => {
    if (customerPassword === 'customer1') {
      alert('Welcome back, let\'s get you something to eat!');
      navigation.navigate('Menu'); // Navigate to Menu Screen for Customer
    } else {
      alert('Incorrect Customer password.');
    }
  };

  return (
    <View style={styles.container}>
      {/* Bold text at the top */}
      <Text style={styles.header}>Welcome To Celestial Bites</Text>

      <Text>Welcome Chef!</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Chef Password"
        secureTextEntry
        value={chefPassword}
        onChangeText={setChefPassword}
      />
      <Button 
        title="Login as Chef" 
        onPress={handleChefLogin} 
        color="#800080" 
      />

      <Text>Welcome Customer!</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Customer Password"
        secureTextEntry
        value={customerPassword}
        onChangeText={setCustomerPassword}
      />
      <Button 
        title="Login as Customer" 
        onPress={handleCustomerLogin} 
        color="#800080" 
      />

      <StatusBar style="auto" />
    </View>
  );
}

// Main App Component (with Navigation)
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Menu" component={MenuScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',  // Set background color to pink
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold', // Make the header text bold
    marginBottom: 20,  // Space between header and next elements
  },
  input: {
    height: 40,
    borderColor: 'white',
    borderWidth: 1,
    marginBottom: 10,
    width: '100%',
    paddingLeft: 8,
  },
});
