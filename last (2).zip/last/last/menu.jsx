import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';


const Stack = createStackNavigator();

// Menu Screen that the chef will see and choose where he wants to make changes/updates 
function MenuScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu</Text>

      <ScrollView style={styles.menuContainer}>
        {/* Starters Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Starters</Text>
          <Text style={styles.courseDescription}>
            A selection of light and flavorful appetizers to begin your meal.
          </Text>
          <Text style={styles.coursePrice}>R35.00</Text>
          <Text>Baked Camembert</Text>
          <Button title="Select" onPress={() => alert('Successfully placed Baked Camembert in cart')} color="#800080" />
          <Text>Mushroom Soup</Text>
          <Button title="Select" onPress={() => alert('Successfully placed Mushroom Soup in cart')} color="#800080" />
        </View>

        <Button
          title="Edit Starters?"
          onPress={() => navigation.navigate('EditPage')}
          color="#800080"
        />

        {/* Main Course */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Main Course</Text>
          <Text style={styles.courseDescription}>
            Our finest main dishes to satisfy your hunger and cravings.
          </Text>
          <Text style={styles.coursePrice}>R105.99</Text>
          <Text>Beef Enchiladas</Text>
          <Button title="Select" onPress={() => alert('Successfully added Beef Enchiladas to your cart')} color="#800080" />
        </View>

        <Button
          title="Edit Main Courses?"
          onPress={() => navigation.navigate('EditPage')}
          color="#800080"
        />

        {/* Dessert Section */}
        <View style={styles.courseContainer}>
          <Text style={styles.courseTitle}>Dessert</Text>
          <Text style={styles.courseDescription}>
            Sweet and delightful desserts to end your meal on a high note.
          </Text>
          <Text style={styles.coursePrice}>R34.99 - R55.00</Text>
          <Text>Malva Pudding</Text>
          <Button title="Select" onPress={() => alert('Malva pudding successfully selected')} color="#800080" />
        </View>

        <Button
          title="Edit Dessert Menu?"
          onPress={() => navigation.navigate('EditPage')}
          color="#800080"
        />

        {/* Next Page Button for Customer */}
        <View style={styles.nextPageButtonContainer}>
          <Button
            title="Next Page (Filter)"
            onPress={() => navigation.navigate('FilterPage')}
            color="#800080"
          />
        </View>

      </ScrollView>

      <StatusBar style="auto" />
    </View>
  );
}

// Edit Page for Chef
function EditPage() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Edit Menu</Text>
      <Text>Chef can edit the menu here.</Text>
      <StatusBar style="auto" />
    </View>
  );
}

// Filter Page for Customer
function FilterPage() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Filter Menu</Text>
      <Text>Customer can filter the menu here.</Text>
      <StatusBar style="auto" />
    </View>
  );
}

// Main App Component (with Navigation)
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Menu">
        <Stack.Screen name="Menu" component={MenuScreen} />
        <Stack.Screen name="EditPage" component={EditPage} />
        <Stack.Screen name="FilterPage" component={FilterPage} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    paddingTop: 50,
    alignItems: 'center',
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
  },
  menuContainer: {
    width: '90%',
  },
  courseContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    alignItems: 'center',
  },
  courseTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#333',
  },
  courseDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginVertical: 10,
  },
  coursePrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2a9d8f',
    marginBottom: 15,
  },
  nextPageButtonContainer: {
    marginTop: 20,
  },
});
